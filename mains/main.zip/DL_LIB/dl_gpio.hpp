#pragma once
#include <stm32f4xx.h>
/**
 * @note 不包含时钟开启!请手动开启时钟
 */

namespace dl{



class GPIO{
    GPIO_TypeDef* gpiox;
    uint32_t GPIO_Pin;
    GPIOMode_TypeDef GPIO_Mode;
    public:
    //TODO时钟开启的问题
    GPIO(GPIO_TypeDef* gpiox,uint32_t GPIO_Pin,GPIOMode_TypeDef GPIO_Mode,GPIOSpeed_TypeDef GPIO_Speed,GPIOOType_TypeDef GPIO_OType,GPIOPuPd_TypeDef GPIO_PuPd){
        this->gpiox = gpiox;
        this->GPIO_Pin = GPIO_Pin;
        this->GPIO_Mode = GPIO_Mode;
        GPIO_InitTypeDef GPIO_InitStruct{
            .GPIO_Pin = GPIO_Pin,
            .GPIO_Mode = GPIO_Mode,
            .GPIO_Speed = GPIO_Speed,
            .GPIO_OType = GPIO_OType,
            .GPIO_PuPd = GPIO_PuPd
        };
        GPIO_Init(gpiox, &GPIO_InitStruct);
    }
    void write(BitAction BitVal) const {
        GPIO_WriteBit(gpiox, GPIO_Pin, BitVal);
    }
    void set() const {
        GPIO_SetBits(gpiox, GPIO_Pin);
    }
    void reset() const {
        GPIO_ResetBits(gpiox, GPIO_Pin);
    }
    uint8_t read(){
        
        if (GPIO_Mode != GPIO_Mode_IN)
        {
            //error
        }
       return GPIO_ReadInputDataBit(gpiox, GPIO_Pin);
    }
};
}
#define debugInit dl::GPIO debug(GPIOA,GPIO_Pin_11,GPIO_Mode_OUT, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);
#define debugGPIO GPIOA,GPIO_Pin_11

#define debugSet GPIO_SetBits(debugGPIO)

#define debugReset GPIO_ResetBits(debugGPIO) 

namespace dl
{
//不可操作,仅为数据结构体封装,这样传递的GPIO+Pin默认作为参数使用且未初始化+未开启时钟/允许重复开启
struct __GPIO_Pin_Type
{
    GPIO_TypeDef* gpiox;
    uint32_t pin;
    dl::__GPIO_Pin_Type operator=(const uint8_t val){
        val==0 ? GPIO_ResetBits(gpiox, pin) : GPIO_SetBits(gpiox, pin);
        return *this;
    }
};
#define dPA0  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_0}
#define dPA1  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_1}
#define dPA2  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_2}
#define dPA3  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_3}
#define dPA4  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_4}
#define dPA5  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_5}
#define dPA6  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_6}
#define dPA7  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_7}
#define dPA8  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_8}
#define dPA9  dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_9}
#define dPA10 dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_10}
#define dPA11 dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_11}
#define dPA12 dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_12}
#define dPA13 dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_13}
#define dPA14 dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_14}
#define dPA15 dl::__GPIO_Pin_Type{GPIOA,GPIO_Pin_15}
#define dPB0  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_0}
#define dPB1  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_1}
#define dPB2  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_2}
#define dPB3  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_3}
#define dPB4  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_4}
#define dPB5  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_5}
#define dPB6  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_6}
#define dPB7  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_7}
#define dPB8  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_8}
#define dPB9  dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_9}
#define dPB10 dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_10}
#define dPB11 dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_11}
#define dPB12 dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_12}
#define dPB13 dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_13}
#define dPB14 dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_14}
#define dPB15 dl::__GPIO_Pin_Type{GPIOB,GPIO_Pin_15}
#define dPC0  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_0}
#define dPC1  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_1}
#define dPC2  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_2}
#define dPC3  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_3}
#define dPC4  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_4}
#define dPC5  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_5}
#define dPC6  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_6}
#define dPC7  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_7}
#define dPC8  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_8}
#define dPC9  dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_9}
#define dPC10 dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_10}
#define dPC11 dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_11}
#define dPC12 dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_12}
#define dPC13 dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_13}
#define dPC14 dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_14}
#define dPC15 dl::__GPIO_Pin_Type{GPIOC,GPIO_Pin_15}
#define dPD0  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_0}
#define dPD1  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_1}
#define dPD2  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_2}
#define dPD3  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_3}
#define dPD4  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_4}
#define dPD5  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_5}
#define dPD6  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_6}
#define dPD7  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_7}
#define dPD8  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_8}
#define dPD9  dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_9}
#define dPD10 dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_10}
#define dPD11 dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_11}
#define dPD12 dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_12}
#define dPD13 dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_13}
#define dPD14 dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_14}
#define dPD15 dl::__GPIO_Pin_Type{GPIOD,GPIO_Pin_15}
#define dPE0  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_0}
#define dPE1  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_1}
#define dPE2  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_2}
#define dPE3  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_3}
#define dPE4  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_4}
#define dPE5  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_5}
#define dPE6  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_6}
#define dPE7  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_7}
#define dPE8  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_8}
#define dPE9  dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_9}
#define dPE10 dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_10}
#define dPE11 dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_11}
#define dPE12 dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_12}
#define dPE13 dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_13}
#define dPE14 dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_14}
#define dPE15 dl::__GPIO_Pin_Type{GPIOE,GPIO_Pin_15}
#define dPF0  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_0}
#define dPF1  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_1}
#define dPF2  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_2}
#define dPF3  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_3}
#define dPF4  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_4}
#define dPF5  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_5}
#define dPF6  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_6}
#define dPF7  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_7}
#define dPF8  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_8}
#define dPF9  dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_9}
#define dPF10 dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_10}
#define dPF11 dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_11}
#define dPF12 dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_12}
#define dPF13 dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_13}
#define dPF14 dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_14}
#define dPF15 dl::__GPIO_Pin_Type{GPIOF,GPIO_Pin_15}
#define dPG0  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_0}
#define dPG1  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_1}
#define dPG2  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_2}
#define dPG3  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_3}
#define dPG4  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_4}
#define dPG5  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_5}
#define dPG6  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_6}
#define dPG7  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_7}
#define dPG8  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_8}
#define dPG9  dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_9}
#define dPG10 dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_10}
#define dPG11 dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_11}
#define dPG12 dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_12}
#define dPG13 dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_13}
#define dPG14 dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_14}
#define dPG15 dl::__GPIO_Pin_Type{GPIOG,GPIO_Pin_15}

} // namespace dl
