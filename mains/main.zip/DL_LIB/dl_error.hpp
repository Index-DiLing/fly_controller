/**
 * @file dl_error.hpp
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2025-12-18
 * 
 * @copyright Copyright (c) 2025
 * 
 * @todo ERROR
 * 
 */

#pragma once

#include "stm32f4xx.h"



void error(){
    //错误码处理
}
