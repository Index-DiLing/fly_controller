
#include "stm32f4xx.h"
#include "dl_spi.hpp"
#include "dl_gpio.hpp"
namespace dl
{
    //SCK MISO MOSI
    //PA5 P         A6  PA7
    class DL_SPI1 : public SPI
    {
    public:
        dl::GPIO nss;
        DL_SPI1(
            uint16_t SPI_Direction_, // 方向

            uint16_t SPI_Mode_, // 主从模式

            uint16_t SPI_DataSize_, // 数据大小

            uint16_t SPI_CPOL_, // 时钟极性

            uint16_t SPI_CPHA_, // 时钟相位

            uint16_t SPI_NSS_, // 片选管理

            uint16_t SPI_BaudRatePrescaler_, // 波特率预分频

            uint16_t SPI_FirstBit_, // 数据位顺序

            uint16_t SPI_CRCPolynomial_, // CRC多项式

            GPIO_TypeDef *nss_gpio,

            uint16_t nss_pin) : nss(nss_gpio, nss_pin, GPIO_Mode_OUT, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP)
        {
            SPI_InitTypeDef init = SPI_InitTypeDef{
                .SPI_Direction         = SPI_Direction_,
                .SPI_Mode              = SPI_Mode_,
                .SPI_DataSize          = SPI_DataSize_,
                .SPI_CPOL              = SPI_CPOL_,
                .SPI_CPHA              = SPI_CPHA_,
                .SPI_NSS               = SPI_NSS_,
                .SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_,
                .SPI_FirstBit          = SPI_FirstBit_,
                .SPI_CRCPolynomial     = SPI_CRCPolynomial_
            };

            RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
            RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1,ENABLE);
            
            // 初始化IO
            dl::GPIO sck(GPIOA, GPIO_Pin_5, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);
            dl::GPIO miso(GPIOA, GPIO_Pin_6, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);
            dl::GPIO mosi(GPIOA, GPIO_Pin_7, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);
            // IO复用
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_SPI1);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_SPI1);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_SPI1);

            // SPI初始化
            SPI_Init(SPI1, &init);
            SPI_Cmd(SPI1, ENABLE);

            nss.set();
        }
        void send(uint8_t data) override
        {
            SPI_I2S_SendData(SPI1, data);
            while (SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE) == RESET);   
        }
        void send(uint8_t *data, uint16_t size) override
        {
            while (size--) {
                SPI_I2S_SendData(SPI1, *data);
                while (SPI_I2S_GetFlagStatus(SPI1,SPI_I2S_FLAG_TXE) == RESET);
                data++;
            }
        }
        uint16_t read() override
        {
            return SPI_I2S_ReceiveData(SPI1);
        }
        uint16_t read(uint8_t *data) override {
            return 0;
        };
        uint16_t read(uint8_t *data, uint16_t size) override
        {
            return 0;
        }
    };
    dl::DL_SPI1 spi1_impl(
        SPI_Direction_1Line_Tx,
        SPI_Mode_Master,
        SPI_DataSize_8b,
        SPI_CPOL_Low,
        SPI_CPHA_1Edge,
        SPI_NSS_Soft,
        SPI_BaudRatePrescaler_2,
        SPI_FirstBit_MSB,
        7,
        GPIOA,
        GPIO_Pin_4
    );
    dl::SPI &dSPI1 = spi1_impl;
}