#pragma once
#include "stm32f4xx.h"
#include "dl_stream_protocol.hpp"

namespace dl
{
    class SPI: public Stream{
        public:
         virtual ~SPI() = default;
         virtual void send(uint8_t data) = 0;
         virtual void send(uint8_t* data, uint16_t size) = 0;
         //读取一个字节
         virtual uint16_t read() = 0;
         //返回全部未读取的内容
         virtual uint16_t read(uint8_t* data) = 0;
         //返回指定数量的字节,返回值是实际读取到的字节数(直到超时)
         virtual uint16_t read(uint8_t* data, uint16_t size) = 0;
    };
} // namespace dl
