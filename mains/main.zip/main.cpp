
#include "stm32f4xx.h"
#include "dl_gpio.hpp"
#include "dl_nvic_it.h"
#include "dl_delay.hpp"
#include "dl_esp.hpp"
#include "dl_socket.hpp"
#include "dl_usart.hpp"
#include "dl_timer.hpp"
#include "dl_dma.hpp"
#include "dl_dshot.hpp"
#include "dl_iic.hpp"

#include "DL_AHRS/gyro_ekf.h"

#include "DL_AHRS/MadgwickAHRS.h"

#include <string>

#include "mpu/driver_mpu9250_basic.h"

#include "mpu/driver_mpu9250.h"
#define MAX_16_BITS 65536

#define CODE_END    while (1);

inline void init()
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    debugInit;
    GPIO_ResetBits(debugGPIO);
}
// TX:PA9

static char str[300];
static uint8_t rx_buf[128];
/**
 * @brief 占用IO:
 *
 * 接线:
 * PA11 - Debug LED接灯
 * PE9  TIM  CH1  接信号线1
 * PE11 TIM  CH2
 * PE13 TIM  CH3
 * PE14 TIM  CH4
 *
 * 电调负极线与单片机负极线相连
 *
 * @return int
 */
#include "dl_log.h"
#include "dl_math.hpp"
void rcv_callback(uint8_t type)
{
}

int main()
{

    init();
    float g[3];
    float dps[3];
    float ut[3];
    float degrees;

    dl::USART usart1X(dUSART1_tA9_rA10, rx_buf, sizeof(rx_buf), 1, 1, 1520000);
    dl::Socket socket(usart1X);

    log_func = [&socket](const char *msg) {
        socket.sendString(msg);
    };
    logger << "Program Started: \n"
           << LCMD::FLUSH;

    dl::IIC bus(I2C1, 100000, I2C_Mode_I2C, I2C_DutyCycle_2, 0x51, I2C_Ack_Enable, I2C_AcknowledgedAddress_7bit);

    MPU9250_IIC_BUS = &bus;

    if (mpu9250_basic_init(
            MPU9250_INTERFACE_IIC,
            MPU9250_ADDRESS_AD0_LOW) != 0) {
        socket.sendString("mpu9250_fifo_init error\n");
    }
    dl::delay_ms(300);
    logger << "Inited" << LCMD::FLUSH;

    dPA11 = 1;
    while (true) {
        if (mpu9250_basic_read(g, dps, ut) != 0) {
            socket.sendString("mpu9250_dmp_read_all error\n");
        }
        logger << "AC:" << g[0] << " " << g[1] << " " << g[2] << "\n";
        logger << "GR:" << dps[0] << " " << dps[1] << " " << dps[2] << "\n";
        logger << LCMD::FLUSH;
        dl::delay_ms(5);
        // 四组，忽略
    }
    while (1);
}
