#pragma once
#include <stdint.h>
#include <memory>
#include "functional"
#include "Fatfs/ff.h"
#include "global.h"
#include "dl_bme280.hpp"
#include "dl_error.hpp"
namespace dl
{

    namespace message
    {
        void fetchFile(dl::Socket &soc, const char *filename)
        {
            FIL file;
            FILINFO info;
            FRESULT fres = f_stat(filename, &info);

            logger << "START FETCH,File Result: " << fres << LCMD::NFLUSH;

            char f[64] = {'/'};
            strcat(f, filename);

            fres = f_open(&file, f, FA_CREATE_ALWAYS | FA_WRITE);

            logger << "Open File Result: " << fres << LCMD::NFLUSH;

            soc.sendString("<FETCH-INIT> ");
            soc.sendString(filename);
            soc.sendString("\n");

            uint64_t fileSize = 0;

            soc.read((uint8_t *)&fileSize, 8);
            logger << "File Size: " << (uint32_t)(fileSize) << LCMD::NFLUSH;
            uint32_t blockNum = fileSize / 2048;

            uint8_t *recvBuf = new uint8_t[2048];

            logger << "Block Num: " << blockNum << LCMD::NFLUSH;

            uint32_t l = 0;

            while (blockNum--) {

                soc.sendString("<FETCH-BLOCK>\n");
                soc.read(recvBuf, 2048);
                f_write(&file, recvBuf, 2048, &l);
            }
            soc.sendString("<FETCH-BLOCK>\n");
            soc.read(recvBuf, fileSize % 2048);
            f_write(&file, recvBuf, fileSize % 2048, &l);
            f_close(&file);

            delete[] recvBuf;
            logger << "FETCH END" << LCMD::NFLUSH;
        }
        void fetchParam(dl::Socket &soc, const char *paramName)
        {
        }

        void mainTransferBin(dl::Socket soc)
        {
            soc.sendData((uint8_t *)&globalErrorCode, 4);

            soc.sendData((uint8_t *)&dt, 4);

            soc.sendData((uint8_t *)&q0, 4);

            soc.sendData((uint8_t *)&q1, 4);

            soc.sendData((uint8_t *)&q2, 4);

            soc.sendData((uint8_t *)&q3, 4);

            soc.sendData((uint8_t *)&bmeData.pressure, 4);

            soc.sendData((uint8_t *)&bmeData.temperature, 4);

            soc.sendData((uint8_t *)&bmeData.humidity, 2);

            soc.sendData((uint8_t*)&throttleValue[0],2);
            
            soc.sendData((uint8_t*)&throttleValue[1],2);
            
            soc.sendData((uint8_t*)&throttleValue[2],2);
            
            soc.sendData((uint8_t*)&throttleValue[3],2);
        }

        void requestSync(dl::Socket soc){
            soc.sendString("<SYNC>\n");
            uint8_t key = 0;
            soc.read(&key, 1);
            if( key != 157){
                error((uint32_t) 157,"Key Error");
            }
        }
    } // namespace message

} // namespace dl
