#pragma once

#include "stm32f4xx.h"
#include "dl_gpio.hpp"
#include "dl_nvic_it.h"
namespace dl
{


    struct __USART_Type
    {
        USART_TypeDef* usart;

        uint8_t usartIRQn;
        uint32_t usartAPBPeriph;

        __GPIO_Pin_Type txPin;
        __GPIO_Pin_Type rxPin;
        uint16_t GPIO_PinSource;
        uint8_t GPIO_AF;

        uint32_t rtxGPIOAHBPeriph;

    };

    //TODO:这有BUG
    #define dUSART1_tA9_rA10 dl::__USART_Type{USART1, USART1_IRQn, RCC_APB2Periph_USART1, dPA9, dPA10, GPIO_PinSource9, GPIO_AF_USART1, RCC_AHB1Periph_GPIOA}
    #define dUSART1_tB6_rB7  dl::__USART_Type{USART1, USART1_IRQn, RCC_APB2Periph_USART1, dPB6, dPB7,  GPIO_PinSource6, GPIO_AF_USART1, RCC_AHB1Periph_GPIOB}

    #define dUSART2_tA2_rA3  dl::__USART_Type{USART2, USART2_IRQn, RCC_APB1Periph_USART2, dPA2, dPA3,  GPIO_PinSource2, GPIO_AF_USART2, RCC_AHB1Periph_GPIOA}
    #define dUSART2_tD5_rD6  dl::__USART_Type{USART2, USART2_IRQn, RCC_APB1Periph_USART2, dPD5, dPD6,  GPIO_PinSource5, GPIO_AF_USART2, RCC_AHB1Periph_GPIOD}

    #define dUSART3_tB10_rB11 dl::__USART_Type{USART3, USART3_IRQn, RCC_APB1Periph_USART3, dPB10, dPB11, GPIO_PinSource10, GPIO_AF_USART3, RCC_AHB1Periph_GPIOB}
    #define dUSART3_tC10_rC11 dl::__USART_Type{USART3, USART3_IRQn, RCC_APB1Periph_USART3, dPC10, dPC11, GPIO_PinSource10, GPIO_AF_USART3, RCC_AHB1Periph_GPIOC}

    #define dUSART6_tC6_rC7  dl::__USART_Type{USART6, USART6_IRQn, RCC_APB2Periph_USART6, dPC6, dPC7,  GPIO_PinSource6, GPIO_AF_USART6, RCC_AHB1Periph_GPIOC}
    #define dUSART6_tG14_rG9 dl::__USART_Type{USART6, USART6_IRQn, RCC_APB2Periph_USART6, dPG14, dPG9, GPIO_PinSource14, GPIO_AF_USART6, RCC_AHB1Periph_GPIOG}

    class USART{
    private:
        USART_TypeDef *usart;
        uint8_t *rx_buf;
        uint16_t buf_size;
        uint16_t rx_p  = 0;
        uint16_t c_rxp = 0;
        uint8_t usartIRQn = 0;
        /**
         * @brief 这是串口
         * 
         */
    public:
    //弃用 2026.1.15
    /*
        USART(
            uint32_t baudRate,                         // 波特率
            uint16_t wordLength,                       // 字长
            uint16_t stopBits,                         // 停止位
            uint16_t parity,                           // 校验
            uint16_t mode,                             // 模式
            uint16_t hardwareFlowControl,              // 硬件流控
            uint8_t NVIC_IRQChannelPreemptionPriority, // 中断抢占优先级
            uint8_t NVIC_IRQChannelSubPriority,        // 中断子优先级
            USART_TypeDef *_usart
        )
        {
            usart = _usart;
            // 包含时钟开启
            if (usart == USART1) {
                usartIRQn = USART1_IRQn;
                RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
                RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
                dl::GPIO(GPIOA, GPIO_Pin_9, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP);  // T
                dl::GPIO(GPIOA, GPIO_Pin_10, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP); // RX
                GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
                GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);

            } else if (usart == USART2) {
                // 常用映射: PA2 = TX, PA3 = RX
                usartIRQn = USART2_IRQn;
                RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
                RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
                dl::GPIO(GPIOA, GPIO_Pin_2, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP); // TX
                dl::GPIO(GPIOA, GPIO_Pin_3, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP); // RX
                GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
                GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);
            } else if (usart == USART3) {
                // 常用映射: PB10 = TX, PB11 = RX
                usartIRQn = USART3_IRQn;
                RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
                RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
                dl::GPIO(GPIOB, GPIO_Pin_10, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP); // TX
                dl::GPIO(GPIOB, GPIO_Pin_11, GPIO_Mode_AF, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP); // RX
                GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);
                GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3);
            }

            // 初始化USART
            USART_InitTypeDef USART_InitStructure;
            USART_InitTypeDef usart_init = USART_InitTypeDef{
                .USART_BaudRate            = baudRate,
                .USART_WordLength          = wordLength,
                .USART_StopBits            = stopBits,
                .USART_Parity              = parity,
                .USART_Mode                = mode,
                .USART_HardwareFlowControl = hardwareFlowControl
            };
            USART_Init(usart, &usart_init);
            USART_ITConfig(usart, USART_IT_RXNE, ENABLE);
            dl::NVIC_IT_init_plus(usartIRQn, NVIC_IRQChannelPreemptionPriority, NVIC_IRQChannelSubPriority, [this]() {
            if (USART_GetITStatus(usart, USART_IT_RXNE)) {
                    rx_buf[rx_p++] = USART_ReceiveData(usart);
                }
            });
            USART_Cmd(usart, ENABLE);
        }

*/
        USART(__USART_Type usartType,
            uint8_t* rx_buf_ptr,                     // 接收缓冲区指针
            uint16_t rx_buf_size,                      // 接收缓冲区大小
            uint8_t NVIC_IRQChannelPreemptionPriority, // 中断抢占优先级
            uint8_t NVIC_IRQChannelSubPriority,        // 中断子优先级
            uint32_t baudRate,                         // 波特率
            uint16_t wordLength=USART_WordLength_8b,   // 字长
            uint16_t stopBits=USART_StopBits_1,        // 停止位
            uint16_t parity=USART_Parity_No,           // 校验
            uint16_t mode=USART_Mode_Rx | USART_Mode_Tx,// 模式
            uint16_t hardwareFlowControl=USART_HardwareFlowControl_None  // 硬件流控
        ){
            usart = usartType.usart;
            usartIRQn = usartType.usartIRQn;
            buf_size = rx_buf_size;
            rx_buf = rx_buf_ptr;

            RCC_AHB1PeriphClockCmd(usartType.rtxGPIOAHBPeriph, ENABLE);
            RCC_APB2PeriphClockCmd(usartType.usartAPBPeriph, ENABLE);
            
            GPIO_InitTypeDef gpio_init{
                .GPIO_Pin   = usartType.txPin.pin | usartType.rxPin.pin,
                .GPIO_Mode  = GPIO_Mode_AF,
                .GPIO_Speed = GPIO_Speed_50MHz,
                .GPIO_OType = GPIO_OType_PP,
                .GPIO_PuPd  = GPIO_PuPd_UP
            };
            GPIO_Init(usartType.txPin.gpiox, &gpio_init);
            GPIO_Init(usartType.rxPin.gpiox, &gpio_init);

            GPIO_PinAFConfig(usartType.txPin.gpiox, usartType.GPIO_PinSource, usartType.GPIO_AF);
            GPIO_PinAFConfig(usartType.rxPin.gpiox, usartType.GPIO_PinSource, usartType.GPIO_AF);
            USART_InitTypeDef USART_InitStructure;
            USART_InitTypeDef usart_init = USART_InitTypeDef{
                .USART_BaudRate            = baudRate,
                .USART_WordLength          = wordLength,
                .USART_StopBits            = stopBits,
                .USART_Parity              = parity,
                .USART_Mode                = mode,
                .USART_HardwareFlowControl = hardwareFlowControl
            };
            USART_Init(usartType.usart, &usart_init);
            USART_ITConfig(usartType.usart, USART_IT_RXNE, ENABLE);
            dl::NVIC_IT_init_plus(usartType.usartIRQn, NVIC_IRQChannelPreemptionPriority, NVIC_IRQChannelSubPriority, [this]() {
            if (USART_GetITStatus(usart, USART_IT_RXNE)) {
                    rx_buf[rx_p++] = USART_ReceiveData(usart);
                }
            });
            USART_Cmd(usartType.usart, ENABLE);
        }
        
        inline uint16_t rx_buf_size()
        {
            return rx_p - c_rxp;
        }
        
        void send(uint8_t data)
        {
            USART_SendData(usart, data);
            while (USART_GetFlagStatus(usart, USART_FLAG_TXE) == RESET);
        }
        void send(uint8_t *data, uint16_t size)
        {
            for (uint16_t i = 0; i < size; i++) {
                USART_SendData(usart, data[i]);
                while (USART_GetFlagStatus(usart, USART_FLAG_TXE) == RESET);
            }
        }
        // 读取一个字节
        uint16_t read()
        {
            while (rx_buf_size()==0);
            return rx_buf[c_rxp++];
        }
        // 返回全部未读取的内容
        uint16_t read(uint8_t *data)
        {
            uint16_t i = 0;
            while (rx_p > c_rxp) {
                *data++ = rx_buf[c_rxp++];
                i++;
            }
            return i;
        }
        // 返回指定数量的字节(目前是读不到就炸了)
        uint16_t read(uint8_t *data, uint16_t size)
        {
            while (size--) {
                while (!rx_buf_size());
                *data++ = rx_buf[c_rxp++];
            }
            return size;
        }
    };
} // namespace dl

