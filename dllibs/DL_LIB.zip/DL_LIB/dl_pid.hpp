#pragma once 
#include "stm32f4xx.h"
#include "dl_imu.hpp"
#include "global.h"

inline float delta_time(){
    return 0.01;
}



volatile float target_roll, target_pitch, target_yaw;



namespace dl
{
    //PID,根据当前的实际输出和预期输出计算出修正量
    void pid_roll(){
        //改 02 13
        float lose =    target_roll - roll;  // 计算误差,target > actual时为正,正反馈
        float diff = -  mpu9250_data.gyro[0];//计算角速度(微分),取负值负反馈
        float inte =    integral_delta_roll; //积分制,同delta

        float sigma = (lose * PID_ROLL_KP) + (inte * PID_ROLL_KI) + (diff * PID_ROLL_KD);  // 计算PID输出
        //TODO:限幅


        //加入sigma的转速在 02 13. 直接给sigma*系数即可
        
    }


} // namespace dl
