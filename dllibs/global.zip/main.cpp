// For test SD

#include "stm32f4xx.h"
#include "dl_gpio.hpp"
#include "dl_nvic_it.h"
#include "dl_delay.hpp"
#include "dl_socket.hpp"
#include "dl_usart.hpp"
#include "global.h"
#include "dl_iic.hpp"
#include "dl_imu.hpp"
#include "DL_AHRS/MadgwickAHRS.h"
#include "dl_bme280.hpp"

inline void GPIOClockInit()
{
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
}

inline void init()
{
    GPIOClockInit();
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    SysTick_Config(SystemCoreClock / 1000);
    dl::delay_ms(100);

    dl::GPIO_Pin_Init(dGPIOFPin3, GPIO_Mode_OUT, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);
    dl::GPIO_Pin_Init(dGPIOFPin4, GPIO_Mode_OUT, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);
    dl::GPIO_Pin_Init(dGPIOFPin5, GPIO_Mode_OUT, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_NOPULL);

    q0 = 0;
    q1 = -0.77;
    q2 = -0.63;
    q3 = 0;
}
// TX:PA9

static uint8_t rx_buf[256];
/**
 * @brief 占用IO:
 *
 * 接线:
 * PA11 - Debug LED接灯
 * PE9  TIM  CH1  接信号线176
 * PE11 TIM  CH2
 * PE13 TIM  CH3
 * PE14 TIM  CH4
 *
 * 电调负极线与单片机负极线相连
 *
 * @return int
 */
#include "dl_log.h"
#include "dl_message.hpp"
#include "SDIO/stm324x7i_eval_sdio_sd.h"
#include "Fatfs/ff.h"
#include "dl_config.hpp"
#include "dl_error.hpp"
#include "dl_pid.hpp"
#include "dl_dshot.hpp"
dl::IMUGData mpu9250_data;

dl::BME280::bmeData bmeData;

volatile float roll, pitch, yaw;
//#define DSHOT_ENABLE
int main()
{
    const bool testSensor = false;
    const bool rq = true;

    init();
    dl::USART usart1X(dUSART1_tA9_rA10, rx_buf, sizeof(rx_buf), 1, 1, 1520000);
    dl::Socket socket(usart1X);
    log_func = [&socket](const char *msg) {
        socket.sendString(msg);
    };
    dl::delay_ms(1000);
    logger << "Hello, world!" << LCMD::NFLUSH;

    dl::IIC iicBus2(dIIC2_cB10_dB11);
    dl::IIC iicBus1(dIIC1_cA6_dA7);

    dl::MPU9250 mpu9250(MPU9250_ADDRESS_AD0_LOW, &mpu9250_data);

    dPF3 = 1;
    mpu9250.init(512, &iicBus2);
    dPF3 = 0;
    if (rq)
    {
        dPF4 = 1;
        dl::message::requestSync(socket);
        dPF4 = 0;
    }

#ifdef DSHOT_ENABLE
    dl::DShot ds(dl::DSHOT_TIM::DSHOT_TIM1, dl::DSHOT_RATE::DSHOT_300);
    ds.start();
    uint16_t dvalue[4] = {200, 200, 200, 200};
    ds.encodePreLoadDshotData(dvalue);
#endif

    dl::BME280::bme280_init(&iicBus1);

    uint32_t t = SystemClockMilliseconds;
    dPF3       = 1;
    
    while (SystemClockMilliseconds - t < 10000 || testSensor) {
        uint32_t tt = SystemClockMilliseconds;
        mpu9250.read();
        MadgwickAHRSupdate(mpu9250_data.gyro[0] / 57.29f, mpu9250_data.gyro[1] / 57.29f, mpu9250_data.gyro[2] / 57.29f, mpu9250_data.accel[0], mpu9250_data.accel[1], mpu9250_data.accel[2], mpu9250_data.mag[0], mpu9250_data.mag[1], mpu9250_data.mag[2]);
        sampleFreq = (1000.0f / (float)(SystemClockMilliseconds - tt));
        if (SystemClockMilliseconds - tt < 10) {
            dl::delay_ms(10 - SystemClockMilliseconds + tt);
        }
        pitch = fmod(asinf(-2 * q1 * q3 + 2 * q0 * q2) * 57.3f + 180, 360);
        roll  = fmod((atan2f(2 * q2 * q3 + 2 * q0 * q1, -2 * q1 * q1 - 2 * q2 * q2 + 1) * 57.3f + 180), 360);
        yaw   = fmod(atan2f(2 * (q1 * q2 + q0 * q3), q0 * q0 + q1 * q1 - q2 * q2 - q3 * q3) * 57.3f + 180, 360);
        logger << "YPR: " << yaw << " " << pitch << " " << roll << " " << LCMD::NFLUSH;
        logger << "Initing AHRS " << SystemClockMilliseconds - t << LCMD::NFLUSH;
    }
    dPF3 = 0;
    logger << "<SET-MODE-BIN>" << LCMD::NFLUSH;

    target_pitch = 180; //

    while (1) {
        uint32_t tt = SystemClockMilliseconds;
        mpu9250.read();
        MadgwickAHRSupdate(mpu9250_data.gyro[0] / 57.29f, mpu9250_data.gyro[1] / 57.29f, mpu9250_data.gyro[2] / 57.29f, mpu9250_data.accel[0], mpu9250_data.accel[1], mpu9250_data.accel[2], mpu9250_data.mag[0], mpu9250_data.mag[1], mpu9250_data.mag[2]);
        dl::BME280::bme280_read(&iicBus1, &bmeData);
        pitch = fmod(asinf(-2 * q1 * q3 + 2 * q0 * q2) * 57.3f + 180, 360);
        roll  = fmod((atan2f(2 * q2 * q3 + 2 * q0 * q1, -2 * q1 * q1 - 2 * q2 * q2 + 1) * 57.3f + 180), 360);
        yaw   = fmod(atan2f(2 * (q1 * q2 + q0 * q3), q0 * q0 + q1 * q1 - q2 * q2 - q3 * q3) * 57.3f + 180, 360);
        PIDRateControl();
#ifdef DSHOT_ENABLE
        PIDAngleControl(&ds);
#else
        PIDAngleControl(0);
#endif
        // logger << "YPR: " << yaw << " " << pitch << " " << roll << " " << LCMD::NFLUSH;
        // logger << "updatePID throttles: " << (uint32_t)throttleValueF[0] << " " << (uint32_t)throttleValueF[1] << " " << (uint32_t)throttleValueF[2] << " " << (uint32_t)throttleValueF[3] << LCMD::NFLUSH;
        dl::message::mainTransferBin(socket);
        sampleFreq = (1000.0f / (float)(SystemClockMilliseconds - tt));
        if (SystemClockMilliseconds - tt < 10) {
            dl::delay_ms(10 - SystemClockMilliseconds + tt);
        }
    }

    while (1);
}