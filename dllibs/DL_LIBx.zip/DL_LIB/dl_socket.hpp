#pragma once
#include "stm32f4xx.h"
#include "dl_nvic_it.h"
#include "dl_usart.hpp"
// 1Byte命令码
// 发出命令后需要传数据则先传出长度码,一字节短数据两字节长数据,数据接收到位也有回应(0x00);

namespace dl
{
    class Socket
    {
    private:
        dl::USART &usart;

    public:
        Socket(dl::USART &usartx) : usart(usartx)
        {
        }
        // 这两个函数是没有封装的,慎用
        void sendString(const char *str)
        {
            while (*str != '\0') {
                usart.send((uint8_t)*str++);
            }
        }

        void sendCommand(uint8_t cmd)
        {
            usart.send(cmd);
        }
        void sendData(uint8_t *data, uint16_t len)
        {
            usart.send(len >> 8);
            usart.send(len & 0xff);
            usart.send(data, len);
        }
        uint8_t read()
        {
            return usart.read();
        }
    };

} // namusartace dl
