#pragma once
#include "stm32f4xx.h"
#include "dl_imu.hpp"
#include "global.h"
#include "dl_dshot.hpp"
uint32_t last_pid_time    = 0;
float dt;//单位 s
uint16_t throttleValue[4] = {200, 200, 200, 200};

inline uint32_t delta_pid_time()
{
    uint32_t delta = SystemClockMilliseconds - last_pid_time;
    last_pid_time  = SystemClockMilliseconds;
    dt             = delta/1000.0f;
    return delta;
}

inline float limitRange(float value, float min, float max)
{
    if (value < min) return min;
    if (value > max) return max;
    return value;
}
inline float limitRange(float value, float range)
{
    if (value < -range) return -range;
    if (value > range) return range;
}
// #define PID_THROTTLE_LIMIT_MAX 1900
// #define PID_THROTTLE_LIMIT_MIN 200


inline void updatePID()
{
    throttleValue[0] = limitRange(throttleValue[0], PID_THROTTLE_LIMIT_MIN, PID_THROTTLE_LIMIT_MAX);
    throttleValue[1] = limitRange(throttleValue[1], PID_THROTTLE_LIMIT_MIN, PID_THROTTLE_LIMIT_MAX);
    throttleValue[2] = limitRange(throttleValue[2], PID_THROTTLE_LIMIT_MIN, PID_THROTTLE_LIMIT_MAX);
    throttleValue[3] = limitRange(throttleValue[3], PID_THROTTLE_LIMIT_MIN, PID_THROTTLE_LIMIT_MAX);
    foc.encodePreLoadDshotData(throttleValue);
    delta_pid_time();//更新dt
}

float last_lose_roll_rate=0;
float integral_delta_roll_rate = 0;
//目标值直接设置,无需传递.

// #define PID_ROLL_RATE_KP 0.01f // 滚转角速度Kp
// #define PID_ROLL_RATE_KI 0.0001f // 滚转角速度Ki
// #define PID_ROLL_RATE_KD 0.1f // 滚转角速度Kd
// #define PID_ROLL_RATE_ALPHA 10
// #define PID_ROLL_THROTTLE_ADJUST_LIMIT 100

// 油门值限幅最后统一设定.
inline void pid_roll_rate()
{
    float lose = target_roll_rate - roll_rate;
    float diff = (last_lose_roll_rate - lose) / dt;
    float inte = integral_delta_roll_rate;

    
    float sigma = (lose * PID_ROLL_RATE_KP) + (inte * PID_ROLL_RATE_KI) + (diff * PID_ROLL_RATE_KD); // 计算PID输出

    sigma *= PID_ROLL_RATE_ALPHA;
    sigma = limitRange(sigma, PID_ROLL_THROTTLE_ADJUST_LIMIT);
    
    throttleValue[0] += sigma;
    throttleValue[2] += sigma;
    throttleValue[1] -= sigma;
    throttleValue[3] -= sigma;


    last_lose_roll_rate = lose;
    integral_delta_roll_rate += (lose + last_lose_roll_rate) / 2 * dt; // 积分
}
// roll角度由roll角速度控制

float target_roll_rate        = 0;//向上层传递
float last_lose_roll = 0;
float integral_delta_roll     = 0;

// #define PID_ROLL_KP 0.01f // 滚转角Kp
// #define PID_ROLL_KI 0.0001f // 滚转角Ki
// #define PID_ROLL_KD 0.1f // 滚转角Kd
// #define PID_ROLL_ALPHA 10
// #define PID_ROLL_RATE_ADJUST_LIMIT 0.5f // 角速度最大调整量
// #define PID_ROLL_RATE_LIMIT  5 // 角速度最大限制

inline void pid_roll()
{
    // 改 02 13
    float lose = target_roll - roll;                                                  // 计算误差,target > actual时为正,正反馈
    float diff = -(last_lose_roll - lose) / dt;                                       // 计算角速度(微分),取负值负反馈
    float inte = integral_delta_roll;                                                 // 积分制,同delta
    float sigma = (lose * PID_ROLL_KP) + (inte * PID_ROLL_KI) + (diff * PID_ROLL_KD); // 计算PID输出
    sigma *= PID_ROLL_ALPHA;
    sigma = limitRange(sigma, PID_ROLL_RATE_ADJUST_LIMIT);
    
    last_lose_roll = lose;
    integral_delta_roll += (lose + last_lose_roll) / 2 * dt;                          // 积分

    target_roll_rate += sigma;
    target_roll_rate = limitRange(target_roll_rate, PID_ROLL_RATE_LIMIT); // 限幅

}

// y方向速度依赖roll角度(加速度)

float target_roll                   = 0;//向上层传递
float last_lose_velocity_y = 0;
float integral_delta_velocity_y     = 0;

// #define PID_VELOCITY_Y_KP    0.01f   // y方向速度Kp
// #define PID_VELOCITY_Y_KI    0.0001f // y方向速度Ki
// #define PID_VELOCITY_Y_KD    0.1f    // y方向速度Kd
// #define PID_VELOCITY_Y_ALPHA 10
// #define PID_ROLL_ADJUST_LIMIT 0.5f // 最大调整量
// #define PID_ROLL_LIMIT 30

inline void pid_velocity_y()
{
    float lose  = target_velocity_y - velocity_y;
    float diff  = (last_lose_velocity_y - lose) / dt;
    float inte  = integral_delta_velocity_y;
    float sigma = (lose * PID_VELOCITY_Y_KP) + (inte * PID_VELOCITY_Y_KI) + (diff * PID_VELOCITY_Y_KD);
    sigma *= PID_VELOCITY_Y_ALPHA;
    sigma = limitRange(sigma, PID_ROLL_ADJUST_LIMIT);
    // 修改目标roll

    last_lose_velocity_y = lose;
    integral_delta_velocity_y += (lose + last_lose_velocity_y) / 2 * dt; // 积分

    target_roll += sigma;
    target_roll = limitRange(target_roll,PID_ROLL_LIMIT);
}

/*=====================================================================================================*/

/*=====================================================================================================*/

float last_lose_pitch_rate;
float integral_delta_pitch_rate = 0;

// #define PID_PITCH_RATE_KP 0.01f // 滚转角速度Kp
// #define PID_PITCH_RATE_KI 0.0001f // 滚转角速度Ki
// #define PID_PITCH_RATE_KD 0.1f // 滚转角速度Kd
// #define PID_PITCH_RATE_ALPHA 10
// #define PID_PITCH_THROTTLE_ADJUST_LIMIT 100
// 油门值限幅最后统一设定.
inline void pid_pitch_rate()
{
    float lose = target_pitch_rate - pitch_rate;
    float diff = (last_lose_pitch_rate - lose) / dt;
    float inte = integral_delta_pitch_rate;

    
    float sigma = (lose * PID_PITCH_RATE_KP) + (inte * PID_PITCH_RATE_KI) + (diff * PID_PITCH_RATE_KD); // 计算PID输出

    sigma *= PID_PITCH_RATE_ALPHA;
    sigma = limitRange(sigma, PID_PITCH_THROTTLE_ADJUST_LIMIT);
    
    throttleValue[0] += sigma;
    throttleValue[1] += sigma;
    throttleValue[2] -= sigma;
    throttleValue[3] -= sigma;


    last_lose_pitch_rate = lose;
    integral_delta_pitch_rate += (lose + last_lose_pitch_rate) / 2 * dt; // 积分
}
// pitch角度由pitch角速度控制

float target_pitch_rate        = 0;//向上层传递
float last_lose_pitch = 0;
float integral_delta_pitch     = 0;

// #define PID_PITCH_KP 0.01f // 滚转角Kp
// #define PID_PITCH_KI 0.0001f // 滚转角Ki
// #define PID_PITCH_KD 0.1f // 滚转角Kd
// #define PID_PITCH_ALPHA 10

// #define PID_PITCH_RATE_ADJUST_LIMIT 0.5f // 角速度最大调整量

// #define PID_PITCH_RATE_LIMIT  5 // 角速度最大限制

inline void pid_pitch()
{
    // 改 02 13
    float lose = target_pitch - pitch;                                                  // 计算误差,target > actual时为正,正反馈
    float diff = -(last_lose_pitch - lose) / dt;                                       // 计算角速度(微分),取负值负反馈
    float inte = integral_delta_pitch;                                                 // 积分制,同delta
    float sigma = (lose * PID_PITCH_KP) + (inte * PID_PITCH_KI) + (diff * PID_PITCH_KD); // 计算PID输出
    sigma *= PID_PITCH_ALPHA;
    sigma = limitRange(sigma, PID_PITCH_RATE_ADJUST_LIMIT);
    
    last_lose_pitch = lose;
    integral_delta_pitch += (lose + last_lose_pitch) / 2 * dt;                          // 积分

    target_pitch_rate += sigma;
    target_pitch_rate = limitRange(target_pitch_rate, PID_PITCH_RATE_LIMIT); // 限幅

}

// y方向速度依赖pitch角度(加速度)

float target_pitch                   = 0;//向上层传递
float last_lose_velocity_x = 0;
float integral_delta_velocity_x     = 0;

// #define PID_VELOCITY_X_KP    0.01f   // y方向速度Kp
// #define PID_VELOCITY_X_KI    0.0001f // y方向速度Ki
// #define PID_VELOCITY_X_KD    0.1f    // y方向速度Kd

// #define PID_VELOCITY_X_ALPHA 10

// #define PID_PITCH_ADJUST_LIMIT 0.5f // 最大调整量

// #define PID_PITCH_LIMIT 30
inline void pid_velocity_x()
{
    float lose  = target_velocity_x - velocity_x;
    float diff  = (last_lose_velocity_x - lose) / dt;
    float inte  = integral_delta_velocity_x;
    float sigma = (lose * PID_VELOCITY_X_KP) + (inte * PID_VELOCITY_X_KI) + (diff * PID_VELOCITY_X_KD);
    sigma *= PID_VELOCITY_X_ALPHA;
    sigma = limitRange(sigma, PID_PITCH_ADJUST_LIMIT);
    // 修改目标pitch

    last_lose_velocity_x = lose;
    integral_delta_velocity_x += (lose + last_lose_velocity_x) / 2 * dt; // 积分

    target_pitch += sigma;
    target_pitch = limitRange(target_pitch,PID_PITCH_LIMIT);
}


/*============================================================================================================*/


float last_lose_yaw_rate;
float integral_delta_yaw_rate = 0;
//目标值直接设置,无需传递.

// #define PID_YAW_RATE_KP 0.01f // 滚转角速度Kp
// #define PID_YAW_RATE_KI 0.0001f // 滚转角速度Ki
// #define PID_YAW_RATE_KD 0.1f // 滚转角速度Kd
// #define PID_YAW_RATE_ALPHA 10
// #define PID_YAW_THROTTLE_ADJUST_LIMIT 100
// 油门值限幅最后统一设定.
inline void pid_yaw_rate()
{
    float lose = target_yaw_rate - yaw_rate;
    float diff = (last_lose_yaw_rate - lose) / dt;
    float inte = integral_delta_yaw_rate;

    
    float sigma = (lose * PID_YAW_RATE_KP) + (inte * PID_YAW_RATE_KI) + (diff * PID_YAW_RATE_KD); // 计算PID输出

    sigma *= PID_YAW_RATE_ALPHA;
    sigma = limitRange(sigma, PID_YAW_THROTTLE_ADJUST_LIMIT);
    
    throttleValue[0] += sigma;
    throttleValue[3] += sigma;
    
    throttleValue[2] += sigma;
    throttleValue[1] -= sigma;


    last_lose_yaw_rate = lose;
    integral_delta_yaw_rate += (lose + last_lose_yaw_rate) / 2 * dt; // 积分
}
// yaw角度由yaw角速度控制

float target_yaw_rate        = 0;//向上层传递
float last_lose_yaw = 0;
float integral_delta_yaw     = 0;

// #define PID_YAW_KP 0.01f // 滚转角Kp
// #define PID_YAW_KI 0.0001f // 滚转角Ki
// #define PID_YAW_KD 0.1f // 滚转角Kd
// #define PID_YAW_ALPHA 10
// #define PID_YAW_RATE_ADJUST_LIMIT 0.5f // 角速度最大调整量
// #define PID_YAW_RATE_LIMIT  5 // 角速度最大限制

inline void pid_yaw()
{
    // 改 02 13
    float lose = target_yaw - yaw;                                                  // 计算误差,target > actual时为正,正反馈
    float diff = -(last_lose_yaw - lose) / dt;                                       // 计算角速度(微分),取负值负反馈
    float inte = integral_delta_yaw;                                                 // 积分制,同delta
    float sigma = (lose * PID_YAW_KP) + (inte * PID_YAW_KI) + (diff * PID_YAW_KD); // 计算PID输出
    sigma *= PID_YAW_ALPHA;
    sigma = limitRange(sigma, PID_YAW_RATE_ADJUST_LIMIT);
    
    last_lose_yaw = lose;
    integral_delta_yaw += (lose + last_lose_yaw) / 2 * dt;                          // 积分

    target_yaw_rate += sigma;
    target_yaw_rate = limitRange(target_yaw_rate, PID_YAW_RATE_LIMIT); // 限幅

}


float last_lose_velocity_z = 0;
float integral_delta_velocity_z = 0;


#define PID_VELOCITY_Z_KP    0.01f   // z方向速度Kp
#define PID_VELOCITY_Z_KI    0.0001f // z方向速度Ki
#define PID_VELOCITY_Z_KD    0.1f    // z方向速度Kd
#define PID_VELOCITY_Z_ALPHA 10

#define PID_HEIGHT_THROTTLE_ADJUST_LIMIT 100

inline void pid_velocity_z(){
    float lose  = target_velocity_z - velocity_z;
    float diff  = (last_lose_velocity_z - lose) / dt;
    float inte  = integral_delta_velocity_z;
    float sigma = (lose * PID_VELOCITY_Z_KP) + (inte * PID_VELOCITY_Z_KI) + (diff * PID_VELOCITY_Z_KD);

    sigma *= PID_VELOCITY_Z_ALPHA;
    sigma = limitRange(sigma, PID_HEIGHT_THROTTLE_ADJUST_LIMIT);

    //直接改油门
    throttleValue[0] += sigma;
    throttleValue[2] += sigma;
    throttleValue[1] += sigma;
    throttleValue[3] += sigma;

    last_lose_velocity_z = lose;
    integral_delta_velocity_z += (lose + last_lose_velocity_z) / 2 * dt; // 积分
}


void pid(){
    pid_velocity_x();
    pid_velocity_y();
    pid_velocity_z();
    updatePID();
}