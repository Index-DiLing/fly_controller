#ifndef GYRO_EKF_H
#define GYRO_EKF_H


#define EKF_N 3
#define EKF_M 3

#include "tinyekf.h"


typedef struct {
    ekf_t ekf;
} gyro_ekf_t;

void gyro_ekf_init(gyro_ekf_t *g);
void gyro_ekf_update(
    gyro_ekf_t *g,
    const float gyro_meas[3],
    float gyro_filt[3]
);

#endif
