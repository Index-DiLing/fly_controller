#include "gyro_ekf.h"
#include <string.h>

void gyro_ekf_init(gyro_ekf_t *g)
{
    /* 初始协方差（可调） */
    float pdiag[3] = {
        0.1f, 0.1f, 0.1f
    };

    ekf_initialize(&g->ekf, pdiag);
}
void gyro_ekf_update(
    gyro_ekf_t *g,
    const float gyro_meas[3],
    float gyro_filt[3]
)
{
    /* ================== Prediction ================== */

    /* f(x) = x */
    float fx[3];
    memcpy(fx, g->ekf.x, sizeof(fx));

    /* F = I */
    float F[9] = {
        1,0,0,
        0,1,0,
        0,0,1
    };

    /* 过程噪声 Q（决定滤波“软/硬”程度） */
    float Q[9] = {
        0.0005f, 0, 0,
        0, 0.0005f, 0,
        0, 0, 0.0005f
    };

    ekf_predict(&g->ekf, fx, F, Q);

    /* ================== Update ================== */

    /* z = gyro measurement */
    float z[3] = {
        gyro_meas[0],
        gyro_meas[1],
        gyro_meas[2]
    };

    /* h(x) = x */
    float hx[3] = {
        g->ekf.x[0],
        g->ekf.x[1],
        g->ekf.x[2]
    };

    /* H = I */
    float H[9] = {
        1,0,0,
        0,1,0,
        0,0,1
    };

    /* 测量噪声 R（来自陀螺仪噪声） */
    float R[9] = {
        0.02f, 0, 0,
        0, 0.02f, 0,
        0, 0, 0.02f
    };

    ekf_update(&g->ekf, z, hx, H, R);

    /* 输出滤波后的角速度 */
    gyro_filt[0] = g->ekf.x[0];
    gyro_filt[1] = g->ekf.x[1];
    gyro_filt[2] = g->ekf.x[2];
}
