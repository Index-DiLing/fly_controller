#include "dl_spi.hpp"
#include "stm32f4xx.h"
#include "dl_gpio.hpp"
#include "dl_exti.hpp"
namespace dl
{
    enum class NRF24L01_Registers : uint8_t{
        CONFIG = 0x00,
        EN_AA = 0x01,
        EN_RXADDR = 0x02,
        SETUP_AW = 0x03,
        SETUP_RETR = 0x04,
        RF_CH = 0x05,
        RF_SETUP = 0x06,
        STATUS = 0x07,
        OBSERVE_TX = 0x08,
        CD = 0x09,
        RX_ADDR_P0 = 0x0A,
        RX_ADDR_P1 = 0x0B,
        RX_ADDR_P2 = 0x0C,
        RX_ADDR_P3 = 0x0D,
        RX_ADDR_P4 = 0x0E,
        RX_ADDR_P5 = 0x0F,
        TX_ADDR = 0x10,
        RX_PW_P0 = 0x11,
        RX_PW_P1 = 0x12,
        RX_PW_P2 = 0x13,
        RX_PW_P3 = 0x14,
        FIFO_STATUS = 0x17
    };
    enum class NRF24L01_Mode : bool{
        RX = false,
        TX = true
    };


    class nrf24l01
    {
    private:
        NRF24L01_Mode mode;    

        uint8_t* rx_buf;

        uint8_t RX_PACKET_SIZE;
        uint8_t TX_PACKET_SIZE;

        uint8_t* tp;

        uint8_t* tx_buf;

        dl::SPI* spix;

        uint8_t rx_addr[5];
        uint8_t tx_addr[5];
        GPIO_Pin_Type ce;
        GPIO_Pin_Type irq;
    public:
        nrf24l01(dl::SPI* spi,uint8_t* r_buf, uint8_t* t_buf,GPIO_Pin_Config ce,GPIO_Pin_Config irq,uint8_t* rx_addr,uint8_t* tx_addr,uint8_t RPZ=16,uint8_t TPZ=16);


        void writeRegister(NRF24L01_Registers reg, uint8_t value);
        void writeRegister(NRF24L01_Registers reg, uint8_t* value,uint8_t len);
        uint8_t readRegister(NRF24L01_Registers reg);

        void send(uint8_t* data, uint8_t len);
        void receive(uint8_t* data, uint8_t len);

        void init();
        
        ~nrf24l01();

    };
    
    nrf24l01::nrf24l01(dl::SPI* spi,uint8_t* r_buf, uint8_t* t_buf,GPIO_Pin_Config ce,GPIO_Pin_Config irq,uint8_t* rx_addr,uint8_t* tx_addr,uint8_t RPZ,uint8_t TPZ){

        this->ce = ce.pin;
        this->irq = irq.pin;


        spix = spi;
        rx_buf = r_buf;
        tx_buf = t_buf;

        GPIO_Pin_Init(ce,GPIO_Mode_OUT,GPIO_Speed_50MHz,GPIO_OType_PP,GPIO_PuPd_UP);
        GPIO_Pin_Init(irq,GPIO_Mode_IN,GPIO_Speed_50MHz,GPIO_OType_PP,GPIO_PuPd_UP);

        memcpy(this->rx_addr,rx_addr,5);
        memcpy(this->tx_addr,tx_addr,5);


        dl::EXTI_Init(irq,EXTI_Trigger_Rising,1,1,[this](){
            if (mode == NRF24L01_Mode::TX)
            {
                
            }else{
                spix->send(0b01100001);
                this->spix->read(rx_buf,RX_PACKET_SIZE);
            }
            this->ce = 0;
            
        });
    }



     void nrf24l01::writeRegister(NRF24L01_Registers reg, uint8_t value){
        spix->select();
        
        spix->sendOnly(static_cast<uint8_t>(reg));
        spix->sendOnly(value);

        spix->deselect();
     }

    void nrf24l01::writeRegister(NRF24L01_Registers reg, uint8_t* value,uint8_t len){

        spix->select();
        
        spix->sendOnly(static_cast<uint8_t>(reg)|0b00100000);
        spix->sendOnly(value,len);

        spix->deselect();

    }

    
    

    void nrf24l01::init(){
        writeRegister(NRF24L01_Registers::CONFIG,0x0A);
        //全部默认即可,设置一下自己的RX地址
    }
    void nrf24l01::send(uint8_t* data, uint8_t len){
        
        writeRegister(NRF24L01_Registers::TX_ADDR,tx_addr,5);

        writeRegister(NRF24L01_Registers::RX_ADDR_P0,tx_addr,5);
        
        writeRegister(NRF24L01_Registers::CONFIG,0x0B);

        spix->select();

        spix->sendOnly(0b10100000);

        spix->sendOnly(data,len);

        spix->deselect(); 

        ce = 1;
        
        //等待中断把CE置0;

    }

    void nrf24l01::receive(uint8_t* data, uint8_t len){
        writeRegister(NRF24L01_Registers::RX_ADDR_P0,rx_addr,5);
        writeRegister(NRF24L01_Registers::RX_PW_P0,RX_PACKET_SIZE);
        writeRegister(NRF24L01_Registers::CONFIG,0x0F);

        ce = 1;

        //等待中断

    }
    nrf24l01::~nrf24l01()
    {

    }
    
} // namespace dl
