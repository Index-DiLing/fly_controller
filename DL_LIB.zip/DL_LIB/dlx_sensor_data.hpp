#pragma once
#include <stdint.h>
namespace dlx
{
    struct AccelerometerRaw {
        uint16_t data[3];
    };
    struct AccelerometerG {
        float data[3];
    };

    struct GyroscopeRaw {
        uint16_t data[3];
    };

    struct GyroscopeDps {
        float data[3];
    };

    struct GyroscopeRads {
        float data[3];
    };

    struct StandardIMURaw {
        AccelerometerRaw accel;
        GyroscopeRaw gyro;
    };

    struct StandardIMUGDps {
        AccelerometerG accel;
        GyroscopeDps gyro;
    };

    struct StandardIMUGRads {
        AccelerometerG accel;
        GyroscopeRads gyro;
    };

    struct Quaternion {
        float data[4];
    };

} // namespace dlx
